# Bitcoin Price NFT System

- Build: Vite
- Framework/Library: Three.js
- Variant: JavScript 